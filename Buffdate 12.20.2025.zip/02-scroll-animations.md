# ✨ Scroll-Triggered Animations

Make elements gracefully appear as users scroll down your page.

---

## Overview

6 animation types that trigger when elements enter the viewport:

1. **Fade Up** - Fade in while moving up
2. **Fade In** - Simple fade
3. **Scale Up** - Grow into view
4. **Slide Left** - Slide in from left
5. **Slide Right** - Slide in from right
6. **Stagger Children** - Cascade effect for groups

---

## Basic Usage

Just add a class - that's it!

```html
<div class="animate-fade-up">
  I fade up into view
</div>

<div class="animate-fade-in">
  I simply fade in
</div>

<div class="animate-scale-up">
  I grow into view
</div>

<div class="animate-slide-left">
  I slide from the left
</div>

<div class="animate-slide-right">
  I slide from the right
</div>
```

---

## Stagger Children

For groups of elements that should animate one after another:

```html
<div class="stagger-children">
  <div>First (appears immediately)</div>
  <div>Second (0.1s delay)</div>
  <div>Third (0.2s delay)</div>
  <div>Fourth (0.3s delay)</div>
  <div>Fifth (0.4s delay)</div>
  <div>Sixth (0.5s delay)</div>
</div>
```

### Perfect For
- Show card grids
- Feature lists
- Navigation menus
- Gallery items

---

## Custom Delays

Add custom delays with inline styles:

```html
<div class="animate-fade-up" style="transition-delay: 0s">First</div>
<div class="animate-fade-up" style="transition-delay: 0.1s">Second</div>
<div class="animate-fade-up" style="transition-delay: 0.2s">Third</div>
```

---

## FOE Website Example

### Hero Section
```html
<section class="hero">
  <div class="hero-tag animate-fade-up">Feature Showcase</div>
  
  <h1 class="hero-title text-reveal">
    <span class="line"><span class="line-inner">FUNNY OVER</span></span>
    <span class="line"><span class="line-inner">EVERYTHING</span></span>
  </h1>
  
  <p class="hero-subtitle animate-fade-up" style="transition-delay: 0.2s">
    Your tagline here
  </p>
  
  <div class="hero-cta animate-fade-up" style="transition-delay: 0.3s">
    <button class="btn-magnetic">Get Started</button>
  </div>
</section>
```

### Shows Grid
```html
<section class="shows-section">
  <h2 class="ribbon-title animate-scale-up">Featured Shows</h2>
  
  <div class="show-grid stagger-children">
    <div class="show-card card-lift">Show 1</div>
    <div class="show-card card-lift">Show 2</div>
    <div class="show-card card-lift">Show 3</div>
    <div class="show-card card-lift">Show 4</div>
  </div>
</section>
```

### Two-Column Layout
```html
<section class="about">
  <div class="animate-slide-left">
    <img src="photo.jpg" alt="Photo">
  </div>
  
  <div class="animate-slide-right">
    <h2>About Us</h2>
    <p>Content here...</p>
  </div>
</section>
```

---

## How It Works

### With GSAP (Recommended)
If GSAP ScrollTrigger is loaded, it powers the animations:

```javascript
ScrollTrigger.create({
  trigger: element,
  start: 'top 85%',    // Trigger when top hits 85% down viewport
  end: 'bottom 15%',
  onEnter: () => element.classList.add('is-visible'),
});
```

### Fallback (Intersection Observer)
Without GSAP, uses native browser API:

```javascript
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
      }
    });
  },
  { threshold: 0.15 }
);
```

---

## Customizing Animations

### Change Distance
```css
/* More dramatic movement */
.animate-fade-up-far {
  opacity: 0;
  transform: translateY(100px);
  transition: opacity 0.8s ease, transform 0.8s ease;
}

.animate-fade-up-far.is-visible {
  opacity: 1;
  transform: translateY(0);
}
```

### Change Speed
```css
/* Slower animation */
.animate-slow {
  transition-duration: 1.2s;
}

/* Faster animation */
.animate-fast {
  transition-duration: 0.4s;
}
```

### Change Easing
```css
/* Bouncy */
.animate-bounce {
  transition-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

/* Smooth deceleration */
.animate-smooth {
  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
}
```

---

## Trigger Points

Control when animations start:

```javascript
// In features.js, modify ScrollTrigger settings:
ScrollTrigger.create({
  trigger: el,
  start: 'top 90%',  // Start earlier (90% down viewport)
  // or
  start: 'top 70%',  // Start later (70% down viewport)
});
```

---

## Re-animate on Scroll Up

By default, elements stay visible. To re-hide on scroll up:

```javascript
ScrollTrigger.create({
  trigger: el,
  start: 'top 85%',
  end: 'bottom 15%',
  onEnter: () => el.classList.add('is-visible'),
  onLeaveBack: () => el.classList.remove('is-visible'), // Re-hide
});
```

---

## Performance Tips

1. **Don't animate too many elements**
   - Keep it under 50 animated elements per page
   
2. **Use `transform` and `opacity` only**
   - These are GPU-accelerated
   - Avoid animating `width`, `height`, `top`, `left`

3. **Add `will-change` for complex animations**
   ```css
   .animate-fade-up {
     will-change: transform, opacity;
   }
   ```

4. **Respect reduced motion preferences**
   ```css
   @media (prefers-reduced-motion: reduce) {
     .animate-fade-up,
     .animate-slide-left {
       transition: none;
       opacity: 1;
       transform: none;
     }
   }
   ```

---

## Quick Reference

| Animation | Class | Effect |
|-----------|-------|--------|
| Fade Up | `animate-fade-up` | Opacity + translateY |
| Fade In | `animate-fade-in` | Opacity only |
| Scale Up | `animate-scale-up` | Opacity + scale |
| Slide Left | `animate-slide-left` | Opacity + translateX |
| Slide Right | `animate-slide-right` | Opacity + translateX |
| Stagger | `stagger-children` | Cascade on children |

---

## Debugging

If animations aren't working:

1. **Check if GSAP is loaded**
   ```javascript
   console.log(typeof gsap); // Should be 'object'
   console.log(typeof ScrollTrigger); // Should be 'function'
   ```

2. **Check if elements have the class**
   ```javascript
   document.querySelectorAll('.animate-fade-up').length;
   ```

3. **Force trigger for testing**
   ```javascript
   document.querySelectorAll('.animate-fade-up').forEach(el => {
     el.classList.add('is-visible');
   });
   ```

---

Now your page tells a story as users scroll 📖
