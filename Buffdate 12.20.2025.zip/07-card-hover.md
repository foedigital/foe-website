# 📦 Card Hover Effects

Transform your show cards from static to stunning with these 3D and hover effects.

---

## Overview

5 different card effects that can be combined:

1. **3D Tilt** - Cards tilt toward cursor
2. **Lift** - Cards rise on hover
3. **Glow** - Gradient border appears
4. **Zoom Image** - Image scales on hover
5. **Overlay Reveal** - Content slides up

---

## 1. 3D Tilt Effect

The most impressive effect - cards tilt in 3D space following your cursor.

```html
<div class="card-3d" data-tilt>
  <h3>Josh Potter</h3>
  <p>Creek and the Cave</p>
</div>
```

### Configuration
```html
<div class="card-3d" 
     data-tilt 
     data-tilt-max="15"
     data-tilt-speed="400"
     data-tilt-scale="1.02"
     data-tilt-glare="true"
     data-tilt-max-glare="0.2">
  Content
</div>
```

### Options
| Attribute | Default | Description |
|-----------|---------|-------------|
| `data-tilt-max` | 15 | Max tilt rotation (degrees) |
| `data-tilt-speed` | 400 | Animation speed (ms) |
| `data-tilt-scale` | 1.02 | Scale on hover |
| `data-tilt-glare` | true | Enable glare effect |
| `data-tilt-max-glare` | 0.15 | Max glare opacity |

---

## 2. Lift Effect

Simple but effective - cards rise and get a shadow.

```html
<div class="card-lift">
  <h3>Dylan Carlino</h3>
  <p>Cap City Comedy</p>
</div>
```

### CSS Details
```css
.card-lift {
  transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1),
              box-shadow 0.4s ease;
}

.card-lift:hover {
  transform: translateY(-12px);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
}
```

### Customize Lift Amount
```css
.card-lift-subtle:hover {
  transform: translateY(-6px);
}

.card-lift-dramatic:hover {
  transform: translateY(-20px);
}
```

---

## 3. Glow Border Effect

A gradient border that appears on hover - perfect for featured content.

```html
<div class="card-glow">
  <h3>Featured Show</h3>
  <p>Tonight at 8pm</p>
</div>
```

### How It Works
Uses a pseudo-element with gradient background and mask:

```css
.card-glow::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  padding: 2px;
  background: linear-gradient(135deg, var(--foe-orange), transparent 50%);
  -webkit-mask: linear-gradient(#fff 0 0) content-box, 
                linear-gradient(#fff 0 0);
  mask-composite: exclude;
  opacity: 0;
  transition: opacity 0.4s ease;
}

.card-glow:hover::before {
  opacity: 1;
}
```

### Custom Glow Colors
```css
.card-glow-blue::before {
  background: linear-gradient(135deg, #3B82F6, transparent 50%);
}

.card-glow-green::before {
  background: linear-gradient(135deg, #4ADE80, transparent 50%);
}

.card-glow-rainbow::before {
  background: linear-gradient(135deg, 
    #FF6B35, #FBBF24, #4ADE80, #3B82F6, #A855F7);
}
```

---

## 4. Zoom Image Effect

The image inside the card zooms on hover.

```html
<div class="card-zoom-image">
  <img src="comedian.jpg" alt="Comedian">
  <div class="card-content">
    <h3>Jessimae Peluso</h3>
  </div>
</div>
```

### CSS
```css
.card-zoom-image {
  overflow: hidden;
}

.card-zoom-image img {
  transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}

.card-zoom-image:hover img {
  transform: scale(1.1);
}
```

### Variations
```css
/* Slower zoom */
.card-zoom-image img {
  transition-duration: 1s;
}

/* More dramatic zoom */
.card-zoom-image:hover img {
  transform: scale(1.2);
}

/* Zoom out instead */
.card-zoom-out img {
  transform: scale(1.1);
}
.card-zoom-out:hover img {
  transform: scale(1);
}
```

---

## 5. Overlay Reveal

Content slides up from the bottom on hover.

```html
<div class="card-overlay-reveal">
  <img src="show.jpg" alt="Show">
  <div class="overlay">
    <h3>Christmas at The Creek!</h3>
    <p>Saturday, Dec 20 • 7:00 PM</p>
    <button class="btn-magnetic">Get Tickets</button>
  </div>
</div>
```

### CSS
```css
.card-overlay-reveal {
  position: relative;
  overflow: hidden;
}

.card-overlay-reveal .overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, 
    rgba(0, 0, 0, 0.9) 0%, 
    transparent 100%);
  transform: translateY(60%);
  transition: transform 0.5s cubic-bezier(0.16, 1, 0.3, 1);
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.card-overlay-reveal:hover .overlay {
  transform: translateY(0);
}
```

---

## Combining Effects

Effects can be combined for more impact:

```html
<!-- 3D Tilt + Glow + Zoom -->
<div class="card-3d card-glow card-zoom-image" data-tilt>
  <img src="show.jpg" alt="Show">
  <div class="card-content">
    <h3>Big Show</h3>
  </div>
</div>

<!-- Lift + Overlay -->
<div class="card-lift card-overlay-reveal">
  <img src="show.jpg" alt="Show">
  <div class="overlay">
    <h3>Show Name</h3>
  </div>
</div>
```

---

## FOE Show Card Example

Complete example for your comedy show cards:

```html
<div class="show-item-v2 card-3d card-zoom-image" 
     data-tilt 
     data-cursor-text="View"
     style="background-image: url('show-image.jpg');">
  
  <div class="ribbon-corner">Tonight</div>
  
  <div class="show-overlay card-overlay-reveal">
    <div class="show-date-info">
      <span class="day-badge">SAT</span>
      <span class="date-text">Dec 20</span>
    </div>
    <h3>Christmas at The Creek!</h3>
    <span class="venue">Creek and the Cave</span>
    <div class="show-details">
      <a href="#" class="btn-magnetic btn-v2 ripple">
        <span class="btn-bg"></span>
        <span class="btn-text">Tickets</span>
      </a>
    </div>
  </div>
</div>
```

### CSS for Show Cards
```css
.show-item-v2 {
  position: relative;
  height: 400px;
  background-size: cover;
  background-position: center;
  border-radius: var(--radius-lg);
  overflow: hidden;
}

.show-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, 
    rgba(0, 0, 0, 0.95) 0%, 
    rgba(0, 0, 0, 0.4) 50%,
    transparent 100%);
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.show-item-v2:hover .show-overlay {
  background: linear-gradient(to top, 
    rgba(0, 0, 0, 0.98) 0%, 
    rgba(0, 0, 0, 0.6) 100%);
}
```

---

## Performance Tips

1. **Use `will-change` sparingly**
   ```css
   .card-3d {
     will-change: transform;
   }
   ```

2. **Disable on mobile**
   ```javascript
   if ('ontouchstart' in window) {
     // Don't initialize tilt effects
   }
   ```

3. **Reduce motion for accessibility**
   ```css
   @media (prefers-reduced-motion: reduce) {
     .card-lift,
     .card-glow,
     .card-zoom-image img {
       transition: none;
     }
   }
   ```

---

## Quick Reference

| Effect | Class | Best For |
|--------|-------|----------|
| 3D Tilt | `card-3d` + `data-tilt` | Featured cards |
| Lift | `card-lift` | List items, any card |
| Glow | `card-glow` | Special/featured content |
| Zoom | `card-zoom-image` | Image cards |
| Reveal | `card-overlay-reveal` | Cards with hidden details |

---

Your show cards will now feel like a premium streaming service 🎬
