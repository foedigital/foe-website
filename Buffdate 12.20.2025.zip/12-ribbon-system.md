# 🎀 Ribbon Design System

Your favorite feature, expanded into a complete design system!

---

## Overview

The ribbon system includes 6 different variants, all building on the classic banner ribbon aesthetic you already love.

---

## 1. Ribbon Title (Your Original)

The hero ribbon for section headings. Features a hexagonal clip-path, gradient background, and animated shine effect.

```html
<h2 class="ribbon-title">Featured Shows</h2>
```

### With Animation
```html
<h2 class="ribbon-title ribbon-animated">Featured Shows</h2>
```

### CSS Variables
```css
.ribbon-title {
  /* Customize these */
  --ribbon-bg: linear-gradient(135deg, var(--foe-orange) 0%, var(--foe-orange-dark) 100%);
  --ribbon-color: var(--foe-white);
  --ribbon-shadow: 0 10px 30px var(--foe-orange-glow);
}
```

---

## 2. Basic Ribbon

Simple inline ribbon badge for labeling content.

```html
<div class="ribbon">New Show</div>
<div class="ribbon">Sold Out</div>
<div class="ribbon">Tonight</div>
```

### With Animation
```html
<div class="ribbon ribbon-animated">Hot Ticket</div>
```

---

## 3. Corner Ribbon

Perfect for cards - positions in the top-right corner at a 45° angle.

```html
<div class="card" style="position: relative; overflow: hidden;">
  <div class="ribbon-corner">Featured</div>
  <!-- Card content -->
</div>
```

### Usage Tips
- Parent container needs `position: relative` and `overflow: hidden`
- Works great on show cards
- Keep text short (1-2 words)

---

## 4. Ribbon Banner

Full-width banner with pointed ends. Great for announcements.

```html
<div class="ribbon-banner">
  🎤 Live Comedy Every Night 🎤
</div>
```

### Styling
```css
.ribbon-banner {
  margin: 0 -2rem; /* Extend beyond container */
}
```

---

## 5. Ribbon Divider

Horizontal divider with centered badge. Perfect for section breaks.

```html
<div class="ribbon-divider">
  <span>Austin Comedy</span>
</div>
```

### Multiple Styles
```html
<!-- Standard -->
<div class="ribbon-divider"><span>Shows</span></div>

<!-- With emoji -->
<div class="ribbon-divider"><span>🎭 Tonight</span></div>

<!-- All caps -->
<div class="ribbon-divider"><span>FEATURED</span></div>
```

---

## 6. Custom Ribbon Variants

### Success Ribbon
```css
.ribbon-success {
  background: var(--foe-success);
}
.ribbon-success::before,
.ribbon-success::after {
  border-top-color: #2d8a4d;
  border-right-color: #2d8a4d;
}
```

```html
<div class="ribbon ribbon-success">Available</div>
```

### Warning Ribbon
```css
.ribbon-warning {
  background: var(--foe-warning);
  color: var(--foe-black);
}
```

### Outlined Ribbon
```css
.ribbon-outline {
  background: transparent;
  border: 2px solid var(--foe-orange);
  color: var(--foe-orange);
}
```

---

## Complete Example: Show Card with Ribbons

```html
<div class="show-card card-lift" style="position: relative; overflow: hidden;">
  <!-- Corner ribbon for status -->
  <div class="ribbon-corner">Tonight</div>
  
  <!-- Show image -->
  <img src="show-image.jpg" alt="Comedy Show">
  
  <!-- Show info -->
  <div class="show-info">
    <h3>Josh Potter</h3>
    <p>Creek and the Cave</p>
    
    <!-- Inline ribbon for time -->
    <div class="ribbon" style="font-size: 0.75rem; padding: 0.5rem 1rem;">
      8:00 PM
    </div>
    
    <button class="btn-magnetic">Get Tickets</button>
  </div>
</div>
```

---

## JavaScript API

Create ribbons dynamically:

```javascript
// Create basic ribbon
const ribbon = RibbonSystem.create('New Show');
document.querySelector('.card').appendChild(ribbon);

// Create animated ribbon
const animatedRibbon = RibbonSystem.create('Featured', {
  animated: true
});

// Create ribbon title
const title = RibbonSystem.createTitle('Upcoming Shows');
document.querySelector('section').prepend(title);

// Create divider
const divider = RibbonSystem.createDivider('Comedy');
document.querySelector('.section').appendChild(divider);
```

---

## Animation Details

### Shine Effect
The `.ribbon-animated` class adds a sweeping shine effect:

```css
@keyframes ribbonShine {
  0% { left: -100%; }
  50%, 100% { left: 100%; }
}
```

- Duration: 3 seconds
- Loops infinitely
- Subtle white gradient sweep

### Customizing Animation Speed
```css
.ribbon-animated::after {
  animation-duration: 2s; /* Faster */
}
```

---

## Responsive Behavior

All ribbons are responsive by default:

```css
/* Mobile adjustments */
@media (max-width: 768px) {
  .ribbon-title {
    font-size: 1.25rem;
    padding: 0.75rem 2rem;
  }
  
  .ribbon-banner {
    font-size: 1rem;
    padding: 1rem 2rem;
  }
  
  .ribbon-corner {
    font-size: 0.625rem;
    padding: 0.375rem 1.5rem;
  }
}
```

---

## Color Variants

Quick color classes to add:

```css
/* Add to your CSS */
.ribbon-orange { background: var(--foe-orange); }
.ribbon-dark { background: var(--foe-dark); }
.ribbon-success { background: #4ADE80; }
.ribbon-warning { background: #FBBF24; color: #000; }
.ribbon-error { background: #F87171; }
```

---

## Best Practices

1. **Don't overuse** - One ribbon per card maximum
2. **Keep text short** - 1-3 words work best
3. **Use hierarchy** - `ribbon-title` for headings, `ribbon` for labels
4. **Animate sparingly** - Only animate featured/important ribbons
5. **Consider mobile** - Test that ribbons don't overflow on small screens

---

## FOE-Specific Usage

For the comedy website, use ribbons for:

- **Section titles**: `ribbon-title` for "Featured Shows", "This Week", etc.
- **Show status**: `ribbon-corner` for "Tonight", "Sold Out", "New"
- **Time badges**: `ribbon` for show times
- **Section breaks**: `ribbon-divider` between different categories
- **Announcements**: `ribbon-banner` for special events

```html
<!-- Example: Featured Shows Section -->
<section>
  <h2 class="ribbon-title ribbon-animated">Featured Shows</h2>
  
  <div class="show-grid">
    <div class="show-card">
      <div class="ribbon-corner">Tonight</div>
      <!-- ... -->
    </div>
    <div class="show-card">
      <div class="ribbon-corner" style="background: #F87171;">Sold Out</div>
      <!-- ... -->
    </div>
  </div>
  
  <div class="ribbon-divider"><span>More Shows</span></div>
  
  <!-- Additional content -->
</section>
```

---

Your ribbon game is now 🔥🔥🔥
