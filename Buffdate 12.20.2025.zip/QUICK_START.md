# 🚀 Quick Start Guide

## Add Features to Your FOE Website in 5 Minutes

### Step 1: Add CDN Links

Add these to your HTML `<head>`:

```html
<!-- Fonts (optional but recommended) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Feature Styles -->
<link rel="stylesheet" href="features.css">
```

Add these before `</body>`:

```html
<!-- Animation Libraries -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
<script src="https://unpkg.com/lenis@1.0.42/dist/lenis.min.js"></script>
<script src="https://unpkg.com/vanilla-tilt@1.8.1/dist/vanilla-tilt.min.js"></script>

<!-- Feature Script -->
<script src="features.js"></script>

<!-- Initialize -->
<script>
  const foe = new FOEFeatures();
</script>
```

### Step 2: Add Classes to Your HTML

That's it! Now just add classes to your existing elements:

```html
<!-- Scroll Animations -->
<div class="animate-fade-up">I fade up when scrolled into view</div>
<div class="animate-slide-left">I slide from left</div>
<div class="animate-scale-up">I scale up</div>

<!-- Card Effects -->
<div class="card-3d" data-tilt>I tilt in 3D</div>
<div class="card-lift">I lift on hover</div>
<div class="card-glow">I glow on hover</div>

<!-- Buttons -->
<button class="btn-magnetic ripple">Magnetic Button</button>

<!-- Ribbons (your favorite!) -->
<h2 class="ribbon-title">Featured Shows</h2>
<div class="ribbon">New Show</div>
<div class="ribbon-divider"><span>Comedy</span></div>

<!-- Glass Effect -->
<div class="glass">Frosted glass card</div>
```

---

## Feature Quick Reference

| Effect | Class | Works On |
|--------|-------|----------|
| Fade up on scroll | `animate-fade-up` | Any element |
| Fade in on scroll | `animate-fade-in` | Any element |
| Scale up on scroll | `animate-scale-up` | Any element |
| Slide from left | `animate-slide-left` | Any element |
| Slide from right | `animate-slide-right` | Any element |
| Stagger children | `stagger-children` | Container |
| 3D tilt | `card-3d` + `data-tilt` | Cards |
| Lift on hover | `card-lift` | Cards |
| Glow border | `card-glow` | Cards |
| Image zoom | `card-zoom-image` | Image cards |
| Magnetic pull | `btn-magnetic` | Buttons |
| Ripple effect | `ripple` | Buttons |
| Glass effect | `glass` | Containers |
| Ribbon title | `ribbon-title` | Headings |
| Ribbon badge | `ribbon` | Inline |
| Ribbon divider | `ribbon-divider` | Section breaks |

---

## Custom Configuration

```javascript
const foe = new FOEFeatures({
  // Enable/disable features
  smoothScroll: true,      // Lenis smooth scroll
  scrollAnimations: true,  // Fade-in effects
  textReveal: true,        // Split text animations
  preloader: false,        // Loading screen (set object for options)
  customCursor: true,      // Custom cursor (disabled on touch)
  magneticButtons: true,   // Button pull effect
  card3DTilt: true,        // 3D card tilt
  microInteractions: true, // Ripples, etc.
  noiseOverlay: true,      // Film grain (set object for options)
  parallax: true,          // Scroll parallax
  themeToggle: true,       // Dark/light mode
  scrollProgress: true     // Progress bar
});
```

### Preloader Options
```javascript
preloader: {
  duration: 2500 // milliseconds
}
```

### Noise Overlay Options
```javascript
noiseOverlay: {
  opacity: 0.03,   // 0-1
  animated: true   // Subtle movement
}
```

---

## Cursor Text on Hover

Add custom text that appears in the cursor on hover:

```html
<a href="#" data-cursor-text="View">Hover me</a>
<button data-cursor-text="Click!">Button</button>
```

---

## Magnetic Strength

Control how strongly buttons pull toward cursor:

```html
<button class="btn-magnetic" data-magnetic-strength="0.5">
  Strong pull
</button>

<button class="btn-magnetic" data-magnetic-strength="0.2">
  Subtle pull
</button>
```

---

## Parallax Speed

```html
<div data-parallax data-parallax-speed="0.3">Slow</div>
<div data-parallax data-parallax-speed="0.8">Fast</div>
```

---

## That's It!

You now have a website with:
- ✅ Buttery smooth scrolling
- ✅ Elements that animate on scroll
- ✅ Custom cursor with hover states
- ✅ Magnetic buttons
- ✅ 3D card effects
- ✅ Film grain texture
- ✅ Beautiful ribbon designs
- ✅ Dark/light mode toggle
- ✅ Scroll progress indicator

**Your comedy website just went from "local open mic" to "Netflix special" ✨**
