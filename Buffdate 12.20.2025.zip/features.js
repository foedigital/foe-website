/* =====================================================
   FUNNY OVER EVERYTHING - FEATURE UPGRADES JS
   15 Cutting-Edge Web Design Features for 2025
   ===================================================== */

// =====================================================
// FEATURE 1: SMOOTH SCROLLING (Lenis)
// =====================================================
class SmoothScroll {
  constructor() {
    this.lenis = null;
    this.init();
  }

  init() {
    // Check if Lenis is available
    if (typeof Lenis === 'undefined') {
      console.warn('Lenis not loaded. Add: <script src="https://unpkg.com/lenis@1.0.42/dist/lenis.min.js"></script>');
      return;
    }

    this.lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    // RAF loop
    const raf = (time) => {
      this.lenis.raf(time);
      requestAnimationFrame(raf);
    };
    requestAnimationFrame(raf);

    // Connect to GSAP ScrollTrigger if available
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      this.lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add((time) => this.lenis.raf(time * 1000));
      gsap.ticker.lagSmoothing(0);
    }

    console.log('✅ Smooth Scroll initialized');
  }

  // Scroll to element
  scrollTo(target, options = {}) {
    if (this.lenis) {
      this.lenis.scrollTo(target, {
        offset: options.offset || 0,
        duration: options.duration || 1.5,
        easing: options.easing || ((t) => Math.min(1, 1.001 - Math.pow(2, -10 * t))),
        ...options
      });
    }
  }

  // Stop scrolling
  stop() {
    if (this.lenis) this.lenis.stop();
  }

  // Start scrolling
  start() {
    if (this.lenis) this.lenis.start();
  }
}


// =====================================================
// FEATURE 2: SCROLL-TRIGGERED ANIMATIONS
// =====================================================
class ScrollAnimations {
  constructor() {
    this.animatedElements = [];
    this.init();
  }

  init() {
    // Find all elements with animation classes
    const selectors = [
      '.animate-fade-up',
      '.animate-fade-in',
      '.animate-scale-up',
      '.animate-slide-left',
      '.animate-slide-right',
      '.stagger-children',
      '.text-reveal',
      '.char-reveal',
      '.text-gradient-reveal'
    ];

    this.animatedElements = document.querySelectorAll(selectors.join(', '));

    if (this.animatedElements.length === 0) return;

    // Use GSAP ScrollTrigger if available, otherwise Intersection Observer
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      this.initGSAP();
    } else {
      this.initIntersectionObserver();
    }

    console.log(`✅ Scroll Animations initialized (${this.animatedElements.length} elements)`);
  }

  initGSAP() {
    this.animatedElements.forEach((el, index) => {
      ScrollTrigger.create({
        trigger: el,
        start: 'top 85%',
        end: 'bottom 15%',
        onEnter: () => el.classList.add('is-visible'),
        onLeave: () => {}, // Keep visible
        onEnterBack: () => el.classList.add('is-visible'),
        onLeaveBack: () => el.classList.remove('is-visible'),
      });
    });
  }

  initIntersectionObserver() {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
      }
    );

    this.animatedElements.forEach((el) => observer.observe(el));
  }
}


// =====================================================
// FEATURE 3: TEXT REVEAL ANIMATIONS
// =====================================================
class TextReveal {
  constructor() {
    this.init();
  }

  init() {
    // Split text into lines
    document.querySelectorAll('.text-reveal').forEach((el) => {
      this.splitIntoLines(el);
    });

    // Split text into characters
    document.querySelectorAll('.char-reveal').forEach((el) => {
      this.splitIntoChars(el);
    });

    console.log('✅ Text Reveal initialized');
  }

  splitIntoLines(element) {
    const text = element.textContent;
    const words = text.split(' ');
    
    // Simple approach: treat whole text as one line
    // For multi-line support, use a library like SplitType
    element.innerHTML = `
      <span class="line">
        <span class="line-inner">${text}</span>
      </span>
    `;
  }

  splitIntoChars(element) {
    const text = element.textContent;
    const chars = text.split('');
    
    element.innerHTML = chars
      .map((char, i) => {
        const isSpace = char === ' ' ? '&nbsp;' : char;
        return `<span class="char" style="transition-delay: ${i * 0.03}s">${isSpace}</span>`;
      })
      .join('');
  }
}


// =====================================================
// FEATURE 4: PRELOADER
// =====================================================
class Preloader {
  constructor(options = {}) {
    this.options = {
      duration: options.duration || 2000,
      onComplete: options.onComplete || (() => {}),
      ...options
    };
    this.preloader = null;
    this.counter = null;
    this.init();
  }

  init() {
    this.preloader = document.querySelector('.preloader');
    this.counter = document.querySelector('.preloader-counter span, #preloader-counter');
    
    if (!this.preloader) {
      console.log('No preloader element found');
      return;
    }

    // Animate counter
    if (this.counter) {
      this.animateCounter();
    }

    // Hide preloader after duration
    setTimeout(() => {
      this.hide();
    }, this.options.duration);

    console.log('✅ Preloader initialized');
  }

  animateCounter() {
    let current = 0;
    const target = 100;
    const increment = target / (this.options.duration / 16);

    const updateCounter = () => {
      current += increment;
      if (current < target) {
        this.counter.textContent = Math.floor(current);
        requestAnimationFrame(updateCounter);
      } else {
        this.counter.textContent = target;
      }
    };

    updateCounter();
  }

  hide() {
    this.preloader.classList.add('hidden');
    document.body.classList.remove('loading');
    this.options.onComplete();
  }
}


// =====================================================
// FEATURE 5: CUSTOM CURSOR
// =====================================================
class CustomCursor {
  constructor() {
    this.cursor = null;
    this.ring = null;
    this.text = null;
    this.mouseX = 0;
    this.mouseY = 0;
    this.cursorX = 0;
    this.cursorY = 0;
    this.ringX = 0;
    this.ringY = 0;
    this.init();
  }

  init() {
    // Don't initialize on touch devices
    if ('ontouchstart' in window) {
      console.log('Touch device detected, skipping custom cursor');
      return;
    }

    this.createCursor();
    this.bindEvents();
    this.animate();
    document.body.classList.add('custom-cursor');

    console.log('✅ Custom Cursor initialized');
  }

  createCursor() {
    // Create dot
    this.cursor = document.createElement('div');
    this.cursor.className = 'cursor-dot';
    document.body.appendChild(this.cursor);

    // Create ring
    this.ring = document.createElement('div');
    this.ring.className = 'cursor-ring';
    document.body.appendChild(this.ring);

    // Create text
    this.text = document.createElement('div');
    this.text.className = 'cursor-text';
    document.body.appendChild(this.text);
  }

  bindEvents() {
    // Track mouse position
    document.addEventListener('mousemove', (e) => {
      this.mouseX = e.clientX;
      this.mouseY = e.clientY;
    });

    // Interactive elements
    const interactiveElements = document.querySelectorAll('a, button, [data-cursor], input, textarea, select');
    
    interactiveElements.forEach((el) => {
      el.addEventListener('mouseenter', () => {
        this.cursor.classList.add('active');
        this.ring.classList.add('active');

        // Check for custom cursor text
        const cursorText = el.dataset.cursorText || el.dataset.cursor;
        if (cursorText) {
          this.text.textContent = cursorText;
          this.text.classList.add('visible');
          this.ring.classList.add('link-hover');
        }
      });

      el.addEventListener('mouseleave', () => {
        this.cursor.classList.remove('active');
        this.ring.classList.remove('active', 'link-hover');
        this.text.classList.remove('visible');
      });
    });

    // Hide cursor when leaving window
    document.addEventListener('mouseleave', () => {
      this.cursor.style.opacity = '0';
      this.ring.style.opacity = '0';
    });

    document.addEventListener('mouseenter', () => {
      this.cursor.style.opacity = '1';
      this.ring.style.opacity = '1';
    });
  }

  animate() {
    // Smooth follow for cursor dot
    this.cursorX += (this.mouseX - this.cursorX) * 0.5;
    this.cursorY += (this.mouseY - this.cursorY) * 0.5;
    
    // Slower follow for ring
    this.ringX += (this.mouseX - this.ringX) * 0.15;
    this.ringY += (this.mouseY - this.ringY) * 0.15;

    if (this.cursor) {
      this.cursor.style.left = `${this.cursorX}px`;
      this.cursor.style.top = `${this.cursorY}px`;
    }

    if (this.ring) {
      this.ring.style.left = `${this.ringX}px`;
      this.ring.style.top = `${this.ringY}px`;
    }

    if (this.text) {
      this.text.style.left = `${this.cursorX}px`;
      this.text.style.top = `${this.cursorY}px`;
    }

    requestAnimationFrame(() => this.animate());
  }
}


// =====================================================
// FEATURE 6: MAGNETIC BUTTONS
// =====================================================
class MagneticButtons {
  constructor() {
    this.buttons = [];
    this.init();
  }

  init() {
    this.buttons = document.querySelectorAll('.btn-magnetic, [data-magnetic]');
    
    if (this.buttons.length === 0) return;

    this.buttons.forEach((btn) => this.addMagneticEffect(btn));

    console.log(`✅ Magnetic Buttons initialized (${this.buttons.length} buttons)`);
  }

  addMagneticEffect(element) {
    const strength = parseFloat(element.dataset.magneticStrength) || 0.3;

    element.addEventListener('mousemove', (e) => {
      const rect = element.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;

      if (typeof gsap !== 'undefined') {
        gsap.to(element, {
          x: x * strength,
          y: y * strength,
          duration: 0.3,
          ease: 'power2.out'
        });
      } else {
        element.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
      }
    });

    element.addEventListener('mouseleave', () => {
      if (typeof gsap !== 'undefined') {
        gsap.to(element, {
          x: 0,
          y: 0,
          duration: 0.3,
          ease: 'power2.out'
        });
      } else {
        element.style.transform = 'translate(0, 0)';
      }
    });
  }
}


// =====================================================
// FEATURE 7: CARD HOVER EFFECTS (3D Tilt)
// =====================================================
class Card3DTilt {
  constructor() {
    this.cards = [];
    this.init();
  }

  init() {
    this.cards = document.querySelectorAll('.card-3d, [data-tilt]');
    
    if (this.cards.length === 0) return;

    // Use Vanilla Tilt if available
    if (typeof VanillaTilt !== 'undefined') {
      VanillaTilt.init(this.cards, {
        max: 15,
        speed: 400,
        scale: 1.02,
        glare: true,
        'max-glare': 0.15,
        perspective: 1000
      });
    } else {
      // Fallback to custom implementation
      this.cards.forEach((card) => this.addTiltEffect(card));
    }

    console.log(`✅ Card 3D Tilt initialized (${this.cards.length} cards)`);
  }

  addTiltEffect(element) {
    element.addEventListener('mousemove', (e) => {
      const rect = element.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = (y - centerY) / 10;
      const rotateY = (centerX - x) / 10;

      element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
    });

    element.addEventListener('mouseleave', () => {
      element.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
    });
  }
}


// =====================================================
// FEATURE 8: MICRO-INTERACTIONS
// =====================================================
class MicroInteractions {
  constructor() {
    this.init();
  }

  init() {
    this.initRipple();
    this.initButtonFeedback();
    console.log('✅ Micro-interactions initialized');
  }

  initRipple() {
    document.querySelectorAll('.ripple').forEach((el) => {
      el.addEventListener('click', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const ripple = document.createElement('span');
        ripple.className = 'ripple-effect';
        ripple.style.cssText = `
          position: absolute;
          width: 10px;
          height: 10px;
          background: rgba(255, 255, 255, 0.4);
          border-radius: 50%;
          transform: translate(-50%, -50%) scale(0);
          left: ${x}px;
          top: ${y}px;
          animation: rippleExpand 0.6s ease-out forwards;
        `;

        el.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
      });
    });

    // Add ripple animation if not in CSS
    if (!document.querySelector('#ripple-styles')) {
      const style = document.createElement('style');
      style.id = 'ripple-styles';
      style.textContent = `
        @keyframes rippleExpand {
          to {
            transform: translate(-50%, -50%) scale(40);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
    }
  }

  initButtonFeedback() {
    document.querySelectorAll('button, .btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        btn.classList.add('clicked');
        setTimeout(() => btn.classList.remove('clicked'), 150);
      });
    });
  }

  // Utility: Add shake effect
  static shake(element) {
    element.classList.add('shake');
    setTimeout(() => element.classList.remove('shake'), 500);
  }

  // Utility: Add pulse effect
  static pulse(element) {
    element.classList.add('pulse');
    setTimeout(() => element.classList.remove('pulse'), 2000);
  }
}


// =====================================================
// FEATURE 9: NOISE/GRAIN OVERLAY
// =====================================================
class NoiseOverlay {
  constructor(options = {}) {
    this.options = {
      opacity: options.opacity || 0.04,
      animated: options.animated !== false,
      ...options
    };
    this.init();
  }

  init() {
    // Check if overlay already exists
    if (document.querySelector('.noise-overlay')) {
      console.log('Noise overlay already exists');
      return;
    }

    const overlay = document.createElement('div');
    overlay.className = `noise-overlay ${this.options.animated ? 'animated' : ''}`;
    overlay.style.opacity = this.options.opacity;
    document.body.appendChild(overlay);

    console.log('✅ Noise Overlay initialized');
  }

  setOpacity(value) {
    const overlay = document.querySelector('.noise-overlay');
    if (overlay) overlay.style.opacity = value;
  }

  toggle() {
    const overlay = document.querySelector('.noise-overlay');
    if (overlay) overlay.classList.toggle('animated');
  }
}


// =====================================================
// FEATURE 10: GLASSMORPHISM (Utility)
// =====================================================
// Glassmorphism is CSS-only, but here's a utility to apply it dynamically
class Glassmorphism {
  static apply(element, options = {}) {
    const defaults = {
      blur: 20,
      opacity: 0.6,
      borderOpacity: 0.1,
      background: '26, 26, 26'
    };
    
    const settings = { ...defaults, ...options };

    element.style.cssText += `
      background: rgba(${settings.background}, ${settings.opacity});
      backdrop-filter: blur(${settings.blur}px);
      -webkit-backdrop-filter: blur(${settings.blur}px);
      border: 1px solid rgba(255, 255, 255, ${settings.borderOpacity});
    `;
  }
}


// =====================================================
// FEATURE 11: PARALLAX EFFECTS
// =====================================================
class ParallaxEffects {
  constructor() {
    this.elements = [];
    this.init();
  }

  init() {
    this.elements = document.querySelectorAll('[data-parallax]');
    
    if (this.elements.length === 0) return;

    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      this.initGSAPParallax();
    } else {
      this.initScrollParallax();
    }

    // Mouse parallax
    this.initMouseParallax();

    console.log(`✅ Parallax Effects initialized (${this.elements.length} elements)`);
  }

  initGSAPParallax() {
    this.elements.forEach((el) => {
      const speed = parseFloat(el.dataset.parallaxSpeed) || 0.5;
      const direction = el.dataset.parallaxDirection || 'y';

      gsap.to(el, {
        [direction]: `${speed * 100}%`,
        ease: 'none',
        scrollTrigger: {
          trigger: el.parentElement || el,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true
        }
      });
    });
  }

  initScrollParallax() {
    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;

      this.elements.forEach((el) => {
        const speed = parseFloat(el.dataset.parallaxSpeed) || 0.5;
        const yPos = -(scrolled * speed);
        el.style.transform = `translateY(${yPos}px)`;
      });
    });
  }

  initMouseParallax() {
    const mouseElements = document.querySelectorAll('.mouse-parallax, [data-mouse-parallax]');
    
    if (mouseElements.length === 0) return;

    document.addEventListener('mousemove', (e) => {
      const x = (e.clientX - window.innerWidth / 2) / 50;
      const y = (e.clientY - window.innerHeight / 2) / 50;

      mouseElements.forEach((el) => {
        const speed = parseFloat(el.dataset.mouseParallaxSpeed) || 1;
        el.style.transform = `translate(${x * speed * -1}px, ${y * speed * -1}px)`;
      });
    });
  }
}


// =====================================================
// FEATURE 12: RIBBON SYSTEM (CSS-based, utility here)
// =====================================================
class RibbonSystem {
  // Create ribbon element dynamically
  static create(text, options = {}) {
    const ribbon = document.createElement('div');
    ribbon.className = `ribbon ${options.variant || ''} ${options.animated ? 'ribbon-animated' : ''}`;
    ribbon.textContent = text;
    return ribbon;
  }

  // Create ribbon title
  static createTitle(text, options = {}) {
    const ribbon = document.createElement('h2');
    ribbon.className = 'ribbon-title';
    ribbon.textContent = text;
    return ribbon;
  }

  // Create ribbon divider
  static createDivider(text) {
    const divider = document.createElement('div');
    divider.className = 'ribbon-divider';
    divider.innerHTML = `<span>${text}</span>`;
    return divider;
  }
}


// =====================================================
// FEATURE 13: BENTO GRID (CSS-based, utility here)
// =====================================================
class BentoGrid {
  static init(container) {
    if (!container) return;
    
    // Add animation to children
    const items = container.querySelectorAll('.bento-item');
    items.forEach((item, index) => {
      item.style.transitionDelay = `${index * 0.1}s`;
    });
  }
}


// =====================================================
// FEATURE 14: INFINITE MARQUEE
// =====================================================
class InfiniteMarquee {
  constructor(selector, options = {}) {
    this.container = typeof selector === 'string' ? document.querySelector(selector) : selector;
    this.options = {
      speed: options.speed || 30,
      direction: options.direction || 'left',
      pauseOnHover: options.pauseOnHover !== false,
      ...options
    };
    
    if (this.container) {
      this.init();
    }
  }

  init() {
    const content = this.container.querySelector('.marquee-content');
    if (!content) return;

    // Clone content for seamless loop
    const clone = content.cloneNode(true);
    this.container.querySelector('.marquee-track').appendChild(clone);

    // Set animation speed
    const track = this.container.querySelector('.marquee-track');
    track.style.animationDuration = `${this.options.speed}s`;

    if (this.options.direction === 'right') {
      track.classList.add('reverse');
    }

    if (this.options.pauseOnHover) {
      this.container.addEventListener('mouseenter', () => {
        track.style.animationPlayState = 'paused';
      });
      this.container.addEventListener('mouseleave', () => {
        track.style.animationPlayState = 'running';
      });
    }

    console.log('✅ Infinite Marquee initialized');
  }
}


// =====================================================
// FEATURE 15: DARK/LIGHT MODE TOGGLE
// =====================================================
class ThemeToggle {
  constructor() {
    this.currentTheme = 'dark';
    this.init();
  }

  init() {
    // Check for saved preference
    const savedTheme = localStorage.getItem('foe-theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    this.currentTheme = savedTheme || (systemPrefersDark ? 'dark' : 'light');
    this.applyTheme(this.currentTheme);

    // Bind toggle buttons
    document.querySelectorAll('.theme-toggle, [data-theme-toggle]').forEach((toggle) => {
      toggle.addEventListener('click', () => this.toggle());
    });

    // Listen for system preference changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!localStorage.getItem('foe-theme')) {
        this.applyTheme(e.matches ? 'dark' : 'light');
      }
    });

    console.log(`✅ Theme Toggle initialized (current: ${this.currentTheme})`);
  }

  toggle() {
    this.currentTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
    this.applyTheme(this.currentTheme);
    localStorage.setItem('foe-theme', this.currentTheme);
  }

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    this.currentTheme = theme;

    // Dispatch event for other components
    window.dispatchEvent(new CustomEvent('themechange', { detail: { theme } }));
  }

  getTheme() {
    return this.currentTheme;
  }
}


// =====================================================
// SCROLL PROGRESS BAR
// =====================================================
class ScrollProgress {
  constructor() {
    this.progressBar = null;
    this.init();
  }

  init() {
    // Create progress bar if it doesn't exist
    if (!document.querySelector('.scroll-progress')) {
      this.progressBar = document.createElement('div');
      this.progressBar.className = 'scroll-progress';
      document.body.appendChild(this.progressBar);
    } else {
      this.progressBar = document.querySelector('.scroll-progress');
    }

    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
      gsap.to(this.progressBar, {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: document.body,
          start: 'top top',
          end: 'bottom bottom',
          scrub: 0.3
        }
      });
    } else {
      window.addEventListener('scroll', () => this.updateProgress());
    }

    console.log('✅ Scroll Progress initialized');
  }

  updateProgress() {
    const scrollTop = window.pageYOffset;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = scrollTop / docHeight;
    this.progressBar.style.transform = `scaleX(${progress})`;
  }
}


// =====================================================
// MASTER INITIALIZER
// =====================================================
class FOEFeatures {
  constructor(options = {}) {
    this.options = {
      smoothScroll: true,
      scrollAnimations: true,
      textReveal: true,
      preloader: false,
      customCursor: true,
      magneticButtons: true,
      card3DTilt: true,
      microInteractions: true,
      noiseOverlay: true,
      parallax: true,
      themeToggle: true,
      scrollProgress: true,
      ...options
    };

    this.instances = {};
    this.init();
  }

  init() {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.initFeatures());
    } else {
      this.initFeatures();
    }
  }

  initFeatures() {
    console.log('🎭 Initializing FOE Features...');

    if (this.options.smoothScroll) {
      this.instances.smoothScroll = new SmoothScroll();
    }

    if (this.options.scrollAnimations) {
      this.instances.scrollAnimations = new ScrollAnimations();
    }

    if (this.options.textReveal) {
      this.instances.textReveal = new TextReveal();
    }

    if (this.options.preloader) {
      this.instances.preloader = new Preloader(
        typeof this.options.preloader === 'object' ? this.options.preloader : {}
      );
    }

    if (this.options.customCursor) {
      this.instances.customCursor = new CustomCursor();
    }

    if (this.options.magneticButtons) {
      this.instances.magneticButtons = new MagneticButtons();
    }

    if (this.options.card3DTilt) {
      this.instances.card3DTilt = new Card3DTilt();
    }

    if (this.options.microInteractions) {
      this.instances.microInteractions = new MicroInteractions();
    }

    if (this.options.noiseOverlay) {
      this.instances.noiseOverlay = new NoiseOverlay(
        typeof this.options.noiseOverlay === 'object' ? this.options.noiseOverlay : {}
      );
    }

    if (this.options.parallax) {
      this.instances.parallax = new ParallaxEffects();
    }

    if (this.options.themeToggle) {
      this.instances.themeToggle = new ThemeToggle();
    }

    if (this.options.scrollProgress) {
      this.instances.scrollProgress = new ScrollProgress();
    }

    console.log('🎉 FOE Features initialized!');
  }

  // Get a specific feature instance
  get(feature) {
    return this.instances[feature];
  }
}


// =====================================================
// AUTO-INITIALIZE (optional)
// =====================================================
// Uncomment to auto-initialize all features:
// const foe = new FOEFeatures();

// Or initialize with specific options:
// const foe = new FOEFeatures({
//   preloader: { duration: 2500 },
//   noiseOverlay: { opacity: 0.03 },
//   customCursor: true
// });


// =====================================================
// EXPORT FOR MODULE USE
// =====================================================
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    FOEFeatures,
    SmoothScroll,
    ScrollAnimations,
    TextReveal,
    Preloader,
    CustomCursor,
    MagneticButtons,
    Card3DTilt,
    MicroInteractions,
    NoiseOverlay,
    Glassmorphism,
    ParallaxEffects,
    RibbonSystem,
    BentoGrid,
    InfiniteMarquee,
    ThemeToggle,
    ScrollProgress
  };
}
